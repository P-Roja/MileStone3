package com.StockPricing.Dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;
import com.StockPricing.model.Stock;

public interface StockDao  extends JpaRepository<Stock, Integer> {
	public List<Stock> findByCompanyId( int companyId);

	 @Query("select s from Stock s where s.date between :date1 and :date2")
    public List<Stock> findByDate(@Param("date1") Date date1, @Param("date2") Date date2);
	 
}
